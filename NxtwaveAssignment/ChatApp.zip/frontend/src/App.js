
import './App.css';
import ChatApp from './chatApp';

function App() {
  return (
    <div className="App">
       <h1> Welcome to ReactJs</h1>
       <ChatApp/>
    </div>
  );
}

export default App;
